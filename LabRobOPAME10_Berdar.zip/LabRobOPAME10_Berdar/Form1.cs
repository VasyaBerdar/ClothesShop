﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace LabRobOPAME10_Berdar
{
    public partial class Form1 : Form
    {
        string inputPath = "input.txt";
        string outputPath = "output.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double amount = 0;

            if (checkBoxFile.Checked)
            {
                if (File.Exists(inputPath))
                {
                    string text = File.ReadAllText(inputPath);
                    double.TryParse(text, out amount);
                }
                else
                {
                    MessageBox.Show("Файл не знайдено!");
                    return;
                }
            }
            else
            {
                if (!double.TryParse(textBoxAmount.Text, out amount))
                {
                    MessageBox.Show("Невірне число!");
                    return;
                }
            }

           
            double rate = 0;

            if (radioUSD.Checked)
                rate = 40;   
            else if (radioEUR.Checked)
                rate = 42;   
            else if (radioPLN.Checked)
                rate = 10;   

            double result = amount * rate;

            labelResult.Text = "Результат: " + result + " грн";
        }

        private void checkBoxFile_CheckedChanged(object sender, EventArgs e)
        {
            textBoxAmount.Visible = !checkBoxFile.Checked;
        }
    }
}
