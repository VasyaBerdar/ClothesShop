using System.Windows.Forms;

namespace LabRobOPAME11Berdar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                lblResult.Text = "Результат: Виберіть рядок зі списку!";
                return;
            }

            string inputString = listBox1.SelectedItem.ToString();

            int wordCount = CountWords(inputString);

            lblResult.Text = $"Результат: {wordCount} слів";
        }

        private int CountWords(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return 0;

            string[] words = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return words.Length;
        }
    }
}
