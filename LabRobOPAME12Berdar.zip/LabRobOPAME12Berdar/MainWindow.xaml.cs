﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LabRobOPAME12Berdar
{

    public partial class MainWindow : Window
    {
        private DispatcherTimer animationTimer;

        private double centerX;
        private double centerY;

        private const double planetRadius = 60;

        private Satellite[] satellites;

        private Ellipse planet;
        private Polyline[] orbits;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            centerX = MainCanvas.Width / 2;
            centerY = MainCanvas.Height / 2;

            InitializeSatellites();

            DrawPlanet();
            DrawOrbits();

            animationTimer = new DispatcherTimer();
            animationTimer.Interval = TimeSpan.FromMilliseconds(30);
            animationTimer.Tick += AnimationTimer_Tick;
        }

        private void InitializeSatellites()
        {
            satellites = new Satellite[]
            {
                new Satellite { Name = "Супутник 1", OrbitRadius = 120, SatelliteRadius = 12,
                               Speed = 0.03, Angle = 0, Color = Brushes.LightGray },
                new Satellite { Name = "Супутник 2", OrbitRadius = 180, SatelliteRadius = 10,
                               Speed = -0.02, Angle = Math.PI, Color = Brushes.LightYellow },
                new Satellite { Name = "Супутник 3", OrbitRadius = 240, SatelliteRadius = 14,
                               Speed = 0.015, Angle = Math.PI / 2, Color = Brushes.Orange },
                new Satellite { Name = "Супутник 4", OrbitRadius = 90, SatelliteRadius = 8,
                               Speed = 0.045, Angle = Math.PI / 3, Color = Brushes.LightBlue },
                new Satellite { Name = "Супутник 5", OrbitRadius = 300, SatelliteRadius = 16,
                               Speed = -0.01, Angle = 0, Color = Brushes.White }
            };
        }

        private void DrawPlanet()
        {
            planet = new Ellipse();
            planet.Width = planetRadius * 2;
            planet.Height = planetRadius * 2;
            planet.Fill = Brushes.DodgerBlue;
            planet.Stroke = Brushes.White;
            planet.StrokeThickness = 2;

            Canvas.SetLeft(planet, centerX - planetRadius);
            Canvas.SetTop(planet, centerY - planetRadius);

            MainCanvas.Children.Add(planet);

            Ellipse highlight = new Ellipse();
            highlight.Width = planetRadius;
            highlight.Height = planetRadius;
            highlight.Fill = new RadialGradientBrush(Colors.White, Colors.Transparent);
            highlight.Opacity = 0.4;
            Canvas.SetLeft(highlight, centerX - planetRadius + 5);
            Canvas.SetTop(highlight, centerY - planetRadius + 5);
            MainCanvas.Children.Add(highlight);
        }

        private void DrawOrbits()
        {
            orbits = new Polyline[satellites.Length];

            for (int i = 0; i < satellites.Length; i++)
            {
                Polyline orbit = new Polyline();
                orbit.Stroke = Brushes.Gray;
                orbit.StrokeThickness = 1;
                orbit.StrokeDashArray = new DoubleCollection { 5, 5 };

                double orbitRadius = satellites[i].OrbitRadius;
                int pointsCount = 200;

                for (int j = 0; j <= pointsCount; j++)
                {
                    double angle = 2 * Math.PI * j / pointsCount;
                    double x = centerX + orbitRadius * Math.Cos(angle);
                    double y = centerY + orbitRadius * Math.Sin(angle);
                    orbit.Points.Add(new Point(x, y));
                }

                MainCanvas.Children.Add(orbit);
                orbits[i] = orbit;
            }
        }

        private void DrawSatellites()
        {
            for (int i = MainCanvas.Children.Count - 1; i >= 0; i--)
            {
                if (MainCanvas.Children[i] is Ellipse ellipse && ellipse != planet)
                {
                    if (!ellipse.Fill.ToString().Contains("RadialGradient"))
                    {
                        MainCanvas.Children.RemoveAt(i);
                    }
                }
            }

            for (int i = 0; i < satellites.Length; i++)
            {
                double x = centerX + satellites[i].OrbitRadius * Math.Cos(satellites[i].Angle);
                double y = centerY + satellites[i].OrbitRadius * Math.Sin(satellites[i].Angle);

                Ellipse satellite = new Ellipse();
                satellite.Width = satellites[i].SatelliteRadius * 2;
                satellite.Height = satellites[i].SatelliteRadius * 2;
                satellite.Fill = satellites[i].Color;
                satellite.Stroke = Brushes.DarkGray;
                satellite.StrokeThickness = 1;
                satellite.Tag = i;

                Canvas.SetLeft(satellite, x - satellites[i].SatelliteRadius);
                Canvas.SetTop(satellite, y - satellites[i].SatelliteRadius);

                MainCanvas.Children.Add(satellite);
            }
        }

        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < satellites.Length; i++)
            {
                satellites[i].Angle += satellites[i].Speed;
            }

            DrawSatellites();
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            if (!animationTimer.IsEnabled)
            {
                animationTimer.Start();
            }
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            if (animationTimer.IsEnabled)
            {
                animationTimer.Stop();
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveCanvasToPng(MainCanvas, "PlanetWithSatellites.png");
        }

        private void SaveCanvasToPng(Canvas canvas, string filename)
        {
            try
            {
                canvas.Measure(new System.Windows.Size(canvas.Width, canvas.Height));
                canvas.Arrange(new Rect(new System.Windows.Size(canvas.Width, canvas.Height)));

                RenderTargetBitmap renderBitmap = new RenderTargetBitmap(
                    (int)canvas.Width, (int)canvas.Height, 96d, 96d, PixelFormats.Pbgra32);
                renderBitmap.Render(canvas);

                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderBitmap));

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = System.IO.Path.Combine(desktopPath, filename);

                using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
                {
                    encoder.Save(fileStream);
                }

                MessageBox.Show($"Зображення збережено на робочий стіл: {filename}",
                                "Успішно", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка збереження: {ex.Message}",
                                "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class Satellite
    {
        public string Name { get; set; }
        public double OrbitRadius { get; set; }
        public double SatelliteRadius { get; set; }
        public double Speed { get; set; }
        public double Angle { get; set; }
        public Brush Color { get; set; }
    }
}