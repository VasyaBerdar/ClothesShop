﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabRobOPAME8_Berdar
{
    public partial class Form1 : Form
    {
        private bool isRunning = false;
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(0, 255, 255);

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            Start.Enabled = false;

            for (byte r = 0, g = 255, b = 255; r < 255 && g > 0 && b > 0; r += 5, g -= 5, b -= 5)
            {
                this.BackColor = Color.FromArgb(r, g, b);
                await Task.Delay(70);
            }
            Start.Enabled = true;
        }
    }
}
