﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABOPAM6_BERDAR
{
    public abstract class Vehicle
    {
        protected string brand;
        protected double speed;

        protected Vehicle(string brand,double speed)
        {
            this.brand = brand;
            this.speed = speed;
        }
        public abstract void move();
    }

    public class Car : Vehicle,Refuelable
    {

        public Car(string brand,double speed) : base(brand,speed) 
        {
            
        }
        public override void move()
        {
            Console.WriteLine($"Машина, Швидкість {speed}, Бренд машини {brand}");
            refill();
        }

        public void refill()
        {
            Console.WriteLine("Автомобіль заправився");
        }
    }

    public class Airplane : Vehicle, Refuelable
    {

        public Airplane(string brand, double speed) : base(brand, speed)
        {

        }
        public override void move()
        {
            Console.WriteLine($"Самальот, Швидкість {speed}, Бренд самальота {brand}");
            refill();
        }

        public void refill()
        {
            Console.WriteLine("Самальот заправився");
        }
    }

    public class Bicycle : Vehicle
    {

        public Bicycle(string brand, double speed) : base(brand, speed)
        {

        }
        public override void move()
        {
            Console.WriteLine($"Велосипед, Швидкість {speed}, Бренд велосипеда {brand}");
        }
    }

    public interface Refuelable
    {
        public void refill();
    }


}
