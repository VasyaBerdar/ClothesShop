﻿namespace LABOPAM6_BERDAR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vehicle[] vehicles = new Vehicle[] { new Airplane("Байрактар", 100), new Car("Запорожець", 100), new Bicycle("BMX",10)};

            Console.WriteLine("Завдання 1");
            foreach (var vehicle in vehicles)
            {
                vehicle.move();
            }
            Console.WriteLine();

            Animal[] animals = new Animal[] { new Cat(), new Dog(), new Parrot()};

            Console.WriteLine("Завдання 2");
            foreach(var animal in animals)
            {
                animal.Sound();
            }
            Console.WriteLine();

            Console.WriteLine("Завдання 3");

            List<Artifact> inventory = new List<Artifact>();

            inventory.Add(new MagicScroll(101));
            inventory.Add(new AncientSword(202));

            Console.WriteLine("--- Аналіз інвентарю ---");

            foreach (var item in inventory)
            {
                item.Identify();
            }
        }
    }
}
