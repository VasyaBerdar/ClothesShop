﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABOPAM6_BERDAR
{
    public abstract class Animal
    {
        public abstract void Sound();
    }

    public class Dog : Animal
    {
        public override void Sound()
        {
            Console.WriteLine("Гав");
        }
    }

    public class Cat : Animal
    {
        public override void Sound()
        {
            Console.WriteLine("Мяу");
        }
    }

    public class Parrot : Animal
    {
        public override void Sound()
        {
            Console.WriteLine("Піу");
        }
    }
}
