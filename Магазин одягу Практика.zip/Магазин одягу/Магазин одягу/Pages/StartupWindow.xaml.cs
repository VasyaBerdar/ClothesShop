using System.Windows;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class StartupWindow : Window
{
    private readonly StoreService _store;

    public bool IsAdmin { get; private set; }

    public StartupWindow(StoreService store)
    {
        InitializeComponent();
        _store = store;
    }

    private void ClientClick(object sender, RoutedEventArgs e)
    {
        var registrationWindow = new RegistrationWindow(_store) { Owner = this };
        var registrationResult = registrationWindow.ShowDialog();
        if (registrationResult != true)
        {
            return;
        }

        IsAdmin = false;
        DialogResult = true;
        Close();
    }

    private void AdminClick(object sender, RoutedEventArgs e)
    {
        var loginWindow = new AdminLoginWindow(_store) { Owner = this };
        loginWindow.ShowDialog();
        if (!loginWindow.IsAuthorized)
        {
            return;
        }

        IsAdmin = true;
        DialogResult = true;
        Close();
    }
}
