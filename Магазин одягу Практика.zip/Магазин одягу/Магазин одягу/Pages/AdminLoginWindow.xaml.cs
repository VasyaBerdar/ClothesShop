using System.Windows;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class AdminLoginWindow : Window
{
    private readonly StoreService _store;

    public bool IsAuthorized { get; private set; }

    public AdminLoginWindow(StoreService store)
    {
        InitializeComponent();
        _store = store;
    }

    private void LoginClick(object sender, RoutedEventArgs e)
    {
        if (!_store.ValidateAdminPassword(PasswordInput.Password))
        {
            MessageBox.Show("Невірний пароль адміністратора.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        IsAuthorized = true;
        DialogResult = true;
        Close();
    }

    private void CancelClick(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
