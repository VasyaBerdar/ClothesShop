using System.Windows;
using System.Windows.Controls;
using Магазин_одягу.Models;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class CatalogPage : Page
{
    private readonly StoreService _store;
    private readonly Action<Page> _navigate;

    public CatalogPage(StoreService store, Action<Page> navigate)
    {
        InitializeComponent();
        _store = store;
        _navigate = navigate;

        CategoryComboBox.Items.Add("Усі");
        foreach (var category in _store.Products.Select(x => x.Category).Distinct())
        {
            CategoryComboBox.Items.Add(category);
        }

        CategoryComboBox.SelectedIndex = 0;
        ApplyFilters();
    }

    private void FilterChanged(object sender, RoutedEventArgs e)
    {
        ApplyFilters();
    }

    private void DetailsClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: Product product })
        {
            _navigate(new ProductDetailsPage(_store, _navigate, product));
        }
    }

    private void AddToCartClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: Product product })
        {
            return;
        }

        _store.AddToCart(product, 1);
        MessageBox.Show("Товар додано в кошик.", "Кошик", MessageBoxButton.OK, MessageBoxImage.Information);
        ApplyFilters();
    }

    private void ApplyFilters()
    {
        var query = SearchTextBox.Text.Trim();
        var selectedCategory = CategoryComboBox.SelectedItem?.ToString() ?? "Усі";

        var filtered = _store.Products.Where(product =>
            (string.IsNullOrWhiteSpace(query) ||
             product.Name.Contains(query, StringComparison.OrdinalIgnoreCase)) &&
            (selectedCategory == "Усі" || product.Category == selectedCategory))
            .ToList();

        ProductsControl.ItemsSource = filtered;
    }
}
