using System.Windows;
using System.Windows.Controls;
using Магазин_одягу.Models;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class CartPage : Page
{
    private readonly StoreService _store;
    private readonly AppUser? _currentUser;

    public CartPage(StoreService store, AppUser? currentUser)
    {
        InitializeComponent();
        _store = store;
        _currentUser = currentUser;

        if (_currentUser is not null)
        {
            CustomerNameTextBox.Text = _currentUser.FullName;
            CustomerPhoneTextBox.Text = _currentUser.Phone;
        }

        BindCart();
    }

    private void RefreshCartClick(object sender, RoutedEventArgs e)
    {
        foreach (var item in _store.CartItems.ToList())
        {
            _store.UpdateCartQuantity(item.Product, item.Quantity);
        }

        BindCart();
    }

    private void RemoveSelectedClick(object sender, RoutedEventArgs e)
    {
        if (CartGrid.SelectedItem is CartItem item)
        {
            _store.RemoveFromCart(item.Product);
            BindCart();
        }
    }

    private void PlaceOrderClick(object sender, RoutedEventArgs e)
    {
        var order = _store.PlaceOrder(CustomerNameTextBox.Text, CustomerPhoneTextBox.Text);
        if (order is null)
        {
            MessageBox.Show(
                "Перевірте, що кошик не порожній і коректно заповнені поля клієнта.",
                "Помилка оформлення",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        MessageBox.Show(
            $"Замовлення №{order.Id} успішно створено на суму {order.TotalAmount} грн.",
            "Успіх",
            MessageBoxButton.OK,
            MessageBoxImage.Information);

        CustomerNameTextBox.Clear();
        CustomerPhoneTextBox.Clear();
        BindCart();
    }

    private void BindCart()
    {
        CartGrid.ItemsSource = null;
        CartGrid.ItemsSource = _store.CartItems;
        TotalText.Text = $"Загальна сума: {_store.CartTotal} грн";
    }
}
