using System.Windows;
using System.Windows.Controls;
using Магазин_одягу.Models;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class ProductDetailsPage : Page
{
    private readonly StoreService _store;
    private readonly Action<Page> _navigate;
    private readonly Product _product;

    public ProductDetailsPage(StoreService store, Action<Page> navigate, Product product)
    {
        InitializeComponent();
        _store = store;
        _navigate = navigate;
        _product = product;

        NameText.Text = _product.Name;
        MetaText.Text = $"{_product.Category} | Розмір: {_product.Size} | Колір: {_product.Color}";
        PriceText.Text = $"Ціна: {_product.Price} грн";
        StockText.Text = $"На складі: {_product.StockQuantity}";
        DescriptionText.Text = _product.Description;
    }

    private void AddToCartClick(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(QuantityTextBox.Text, out var quantity) || quantity <= 0)
        {
            MessageBox.Show("Введіть коректну кількість.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (quantity > _product.StockQuantity)
        {
            MessageBox.Show("Недостатньо товару на складі.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _store.AddToCart(_product, quantity);
        MessageBox.Show("Товар додано в кошик.", "Кошик", MessageBoxButton.OK, MessageBoxImage.Information);
        _navigate(new CatalogPage(_store, _navigate));
    }

    private void BackClick(object sender, RoutedEventArgs e)
    {
        _navigate(new CatalogPage(_store, _navigate));
    }
}
