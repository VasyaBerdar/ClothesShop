using System.Windows;
using System.Windows.Controls;
using Магазин_одягу.Models;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class AdminPanelPage : Page
{
    private readonly StoreService _store;

    public AdminPanelPage(StoreService store)
    {
        InitializeComponent();
        _store = store;

        ProductsGrid.ItemsSource = _store.Products;
        OrdersGrid.ItemsSource = _store.Orders;
        OrderStatusCombo.ItemsSource = Enum.GetValues<OrderStatus>();
        OrderStatusCombo.SelectedItem = OrderStatus.New;
    }

    private void AddProductClick(object sender, RoutedEventArgs e)
    {
        if (!TryReadProductInputs(out var name, out var category, out var size, out var color, out var price, out var stock, out var description))
        {
            return;
        }

        if (!_store.CreateProduct(name, category, size, color, price, stock, description, out var error))
        {
            MessageBox.Show(error, "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        ClearProductInputs();
    }

    private void UpdateProductClick(object sender, RoutedEventArgs e)
    {
        if (ProductsGrid.SelectedItem is not Product selected)
        {
            MessageBox.Show("Оберіть товар для оновлення.", "Увага", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (!TryReadProductInputs(out var name, out var category, out var size, out var color, out var price, out var stock, out var description))
        {
            return;
        }

        if (!_store.UpdateProduct(selected, name, category, size, color, price, stock, description, out var error))
        {
            MessageBox.Show(error, "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        ProductsGrid.Items.Refresh();
        ClearProductInputs();
    }

    private void DeleteProductClick(object sender, RoutedEventArgs e)
    {
        if (ProductsGrid.SelectedItem is not Product selected)
        {
            MessageBox.Show("Оберіть товар для видалення.", "Увага", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (!_store.DeleteProduct(selected, out var error))
        {
            MessageBox.Show(error, "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        ClearProductInputs();
    }

    private void UpdateOrderStatusClick(object sender, RoutedEventArgs e)
    {
        if (OrdersGrid.SelectedItem is not Order order)
        {
            MessageBox.Show("Оберіть замовлення.", "Увага", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (OrderStatusCombo.SelectedItem is not OrderStatus newStatus)
        {
            return;
        }

        if (!_store.TryUpdateOrderStatus(order, newStatus, out var error))
        {
            MessageBox.Show(error, "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        OrdersGrid.Items.Refresh();
    }

    private void ProductsGridSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ProductsGrid.SelectedItem is not Product selected)
        {
            return;
        }

        NameInput.Text = selected.Name;
        CategoryInput.Text = selected.Category;
        SizeInput.Text = selected.Size;
        ColorInput.Text = selected.Color;
        PriceInput.Text = selected.Price.ToString();
        StockInput.Text = selected.StockQuantity.ToString();
        DescriptionInput.Text = selected.Description;
    }

    private bool TryReadProductInputs(
        out string name,
        out string category,
        out string size,
        out string color,
        out decimal price,
        out int stock,
        out string description)
    {
        name = NameInput.Text;
        category = CategoryInput.Text;
        size = SizeInput.Text;
        color = ColorInput.Text;
        description = DescriptionInput.Text;

        if (!decimal.TryParse(PriceInput.Text, out price))
        {
            MessageBox.Show("Введіть коректну ціну.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            stock = 0;
            return false;
        }

        if (!int.TryParse(StockInput.Text, out stock))
        {
            MessageBox.Show("Введіть коректну кількість на складі.", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        return true;
    }

    private void ClearProductInputs()
    {
        NameInput.Clear();
        CategoryInput.Clear();
        SizeInput.Clear();
        ColorInput.Clear();
        PriceInput.Clear();
        StockInput.Clear();
        DescriptionInput.Clear();
        ProductsGrid.SelectedItem = null;
    }
}
