using System.Windows;
using Магазин_одягу.Services;

namespace Магазин_одягу.Pages;

public partial class RegistrationWindow : Window
{
    private readonly StoreService _store;

    public RegistrationWindow(StoreService store)
    {
        InitializeComponent();
        _store = store;
    }

    private void LoginClick(object sender, RoutedEventArgs e)
    {
        if (!_store.LoginUser(PhoneInput.Text, out var error))
        {
            MessageBox.Show(error, "Помилка входу", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DialogResult = true;
        Close();
    }

    private void RegisterClick(object sender, RoutedEventArgs e)
    {
        if (!_store.RegisterUser(NameInput.Text, PhoneInput.Text, EmailInput.Text, out var error))
        {
            MessageBox.Show(error, "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        DialogResult = true;
        Close();
    }

    private void ExitClick(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
