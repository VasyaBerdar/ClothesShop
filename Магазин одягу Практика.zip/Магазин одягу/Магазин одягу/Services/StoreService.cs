using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Магазин_одягу.Models;

namespace Магазин_одягу.Services;

public class StoreService
{
    private const string AdminPassword = "admin123";
    private readonly string _dataDirectory;
    private readonly string _productsPath;
    private readonly string _ordersPath;
    private readonly string _usersPath;
    private readonly JsonSerializerOptions _jsonOptions;
    private int _nextOrderId = 1;
    private int _nextProductId = 1;
    private int _nextUserId = 1;

    public ObservableCollection<Product> Products { get; } = [];
    public ObservableCollection<CartItem> CartItems { get; } = [];
    public ObservableCollection<Order> Orders { get; } = [];
    public ObservableCollection<AppUser> Users { get; } = [];

    public AppUser? CurrentUser { get; private set; }

    public StoreService()
    {
        _dataDirectory = Path.Combine(AppContext.BaseDirectory, "Data");
        _productsPath = Path.Combine(_dataDirectory, "products.json");
        _ordersPath = Path.Combine(_dataDirectory, "orders.json");
        _usersPath = Path.Combine(_dataDirectory, "users.json");

        _jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true
        };
        _jsonOptions.Converters.Add(new JsonStringEnumConverter());

        EnsureStorage();
        LoadData();
        EnsureSeedProducts();
        RecalculateIds();
    }

    public decimal CartTotal => CartItems.Sum(x => x.LineTotal);

    public bool ValidateAdminPassword(string password) =>
        string.Equals(password, AdminPassword, StringComparison.Ordinal);

    public bool RegisterUser(string fullName, string phone, string email, out string errorMessage)
    {
        if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(phone))
        {
            errorMessage = "Ім'я і телефон є обов'язковими.";
            return false;
        }

        var normalizedPhone = phone.Trim();
        if (Users.Any(x => string.Equals(x.Phone, normalizedPhone, StringComparison.OrdinalIgnoreCase)))
        {
            errorMessage = "Користувач з таким телефоном вже існує. Використайте кнопку входу.";
            return false;
        }

        var user = new AppUser
        {
            Id = _nextUserId++,
            FullName = fullName.Trim(),
            Phone = normalizedPhone,
            Email = email.Trim()
        };

        Users.Add(user);
        CurrentUser = user;
        SaveUsers();
        errorMessage = string.Empty;
        return true;
    }

    public bool LoginUser(string phone, out string errorMessage)
    {
        if (string.IsNullOrWhiteSpace(phone))
        {
            errorMessage = "Вкажіть телефон.";
            return false;
        }

        var normalizedPhone = phone.Trim();
        var user = Users.FirstOrDefault(x =>
            string.Equals(x.Phone, normalizedPhone, StringComparison.OrdinalIgnoreCase));
        if (user is null)
        {
            errorMessage = "Користувача не знайдено. Зареєструйтесь.";
            return false;
        }

        CurrentUser = user;
        errorMessage = string.Empty;
        return true;
    }

    public void AddToCart(Product product, int quantity)
    {
        if (quantity <= 0 || quantity > product.StockQuantity)
        {
            return;
        }

        var existing = CartItems.FirstOrDefault(x => x.Product.Id == product.Id);
        if (existing is null)
        {
            CartItems.Add(new CartItem { Product = product, Quantity = quantity });
            return;
        }

        var newQuantity = existing.Quantity + quantity;
        if (newQuantity <= product.StockQuantity)
        {
            existing.Quantity = newQuantity;
        }
    }

    public void UpdateCartQuantity(Product product, int quantity)
    {
        var existing = CartItems.FirstOrDefault(x => x.Product.Id == product.Id);
        if (existing is null)
        {
            return;
        }

        if (quantity <= 0)
        {
            CartItems.Remove(existing);
            return;
        }

        if (quantity <= product.StockQuantity)
        {
            existing.Quantity = quantity;
            SaveProducts();
        }
    }

    public void RemoveFromCart(Product product)
    {
        var existing = CartItems.FirstOrDefault(x => x.Product.Id == product.Id);
        if (existing is not null)
        {
            CartItems.Remove(existing);
        }
    }

    public Order? PlaceOrder(string customerName, string customerPhone)
    {
        if (string.IsNullOrWhiteSpace(customerName) ||
            string.IsNullOrWhiteSpace(customerPhone) ||
            CartItems.Count == 0)
        {
            return null;
        }

        foreach (var item in CartItems)
        {
            if (item.Quantity > item.Product.StockQuantity)
            {
                return null;
            }
        }

        var order = new Order
        {
            Id = _nextOrderId++,
            CustomerName = customerName.Trim(),
            CustomerPhone = customerPhone.Trim(),
            TotalAmount = CartTotal,
            Status = OrderStatus.New,
            Items = CartItems.Select(x => new OrderItem
            {
                ProductName = x.Product.Name,
                Quantity = x.Quantity,
                UnitPrice = x.Product.Price
            }).ToList()
        };

        foreach (var item in CartItems)
        {
            item.Product.StockQuantity -= item.Quantity;
        }

        Orders.Add(order);
        CartItems.Clear();
        SaveProducts();
        SaveOrders();
        return order;
    }

    public bool CreateProduct(
        string name,
        string category,
        string size,
        string color,
        decimal price,
        int stockQuantity,
        string description,
        out string errorMessage)
    {
        if (!ValidateProduct(name, category, size, color, price, stockQuantity, out errorMessage))
        {
            return false;
        }

        Products.Add(new Product
        {
            Id = _nextProductId++,
            Name = name.Trim(),
            Category = category.Trim(),
            Size = size.Trim(),
            Color = color.Trim(),
            Price = price,
            StockQuantity = stockQuantity,
            Description = description.Trim()
        });
        SaveProducts();

        return true;
    }

    public bool UpdateProduct(
        Product product,
        string name,
        string category,
        string size,
        string color,
        decimal price,
        int stockQuantity,
        string description,
        out string errorMessage)
    {
        if (!ValidateProduct(name, category, size, color, price, stockQuantity, out errorMessage))
        {
            return false;
        }

        product.Name = name.Trim();
        product.Category = category.Trim();
        product.Size = size.Trim();
        product.Color = color.Trim();
        product.Price = price;
        product.StockQuantity = stockQuantity;
        product.Description = description.Trim();
        SaveProducts();
        return true;
    }

    public bool DeleteProduct(Product product, out string errorMessage)
    {
        if (CartItems.Any(x => x.Product.Id == product.Id))
        {
            errorMessage = "Товар не можна видалити, поки він є у кошику.";
            return false;
        }

        Products.Remove(product);
        SaveProducts();
        errorMessage = string.Empty;
        return true;
    }

    public bool TryUpdateOrderStatus(Order order, OrderStatus newStatus, out string errorMessage)
    {
        if (!IsOrderStatusTransitionAllowed(order.Status, newStatus))
        {
            errorMessage = "Недозволений перехід статусу замовлення.";
            return false;
        }

        order.Status = newStatus;
        SaveOrders();
        errorMessage = string.Empty;
        return true;
    }

    private static bool IsOrderStatusTransitionAllowed(OrderStatus current, OrderStatus next)
    {
        if (current == next)
        {
            return true;
        }

        return (current, next) switch
        {
            (OrderStatus.New, OrderStatus.Processing) => true,
            (OrderStatus.Processing, OrderStatus.Completed) => true,
            (OrderStatus.New, OrderStatus.Cancelled) => true,
            (OrderStatus.Processing, OrderStatus.Cancelled) => true,
            _ => false
        };
    }

    private static bool ValidateProduct(
        string name,
        string category,
        string size,
        string color,
        decimal price,
        int stockQuantity,
        out string errorMessage)
    {
        if (string.IsNullOrWhiteSpace(name) ||
            string.IsNullOrWhiteSpace(category) ||
            string.IsNullOrWhiteSpace(size) ||
            string.IsNullOrWhiteSpace(color))
        {
            errorMessage = "Заповніть назву, категорію, розмір і колір.";
            return false;
        }

        if (price <= 0)
        {
            errorMessage = "Ціна має бути більшою за 0.";
            return false;
        }

        if (stockQuantity < 0)
        {
            errorMessage = "Кількість на складі не може бути від'ємною.";
            return false;
        }

        errorMessage = string.Empty;
        return true;
    }

    private void EnsureStorage()
    {
        Directory.CreateDirectory(_dataDirectory);
        EnsureFileExists(_productsPath);
        EnsureFileExists(_ordersPath);
        EnsureFileExists(_usersPath);
    }

    private static void EnsureFileExists(string filePath)
    {
        if (!File.Exists(filePath))
        {
            File.WriteAllText(filePath, "[]");
        }
    }

    private void LoadData()
    {
        LoadCollection(_productsPath, Products);
        LoadCollection(_ordersPath, Orders);
        LoadCollection(_usersPath, Users);
    }

    private void LoadCollection<T>(string path, ObservableCollection<T> target)
    {
        var json = File.ReadAllText(path);
        var items = JsonSerializer.Deserialize<List<T>>(json, _jsonOptions) ?? [];
        target.Clear();
        foreach (var item in items)
        {
            target.Add(item);
        }
    }

    private void SaveProducts() => SaveCollection(_productsPath, Products);
    private void SaveOrders() => SaveCollection(_ordersPath, Orders);
    private void SaveUsers() => SaveCollection(_usersPath, Users);

    private void SaveCollection<T>(string path, IEnumerable<T> items)
    {
        var json = JsonSerializer.Serialize(items, _jsonOptions);
        File.WriteAllText(path, json);
    }

    private void EnsureSeedProducts()
    {
        if (Products.Count > 0)
        {
            return;
        }

        SeedProducts();
        SaveProducts();
    }

    private void RecalculateIds()
    {
        _nextProductId = Products.Count == 0 ? 1 : Products.Max(x => x.Id) + 1;
        _nextOrderId = Orders.Count == 0 ? 1 : Orders.Max(x => x.Id) + 1;
        _nextUserId = Users.Count == 0 ? 1 : Users.Max(x => x.Id) + 1;
    }

    private void SeedProducts()
    {
        Products.Add(new Product
        {
            Id = _nextProductId++,
            Name = "Футболка Basic",
            Category = "Футболки",
            Size = "M",
            Color = "Білий",
            Price = 599,
            StockQuantity = 15,
            Description = "Базова бавовняна футболка на щодень."
        });
        Products.Add(new Product
        {
            Id = _nextProductId++,
            Name = "Джинси Slim",
            Category = "Штани",
            Size = "L",
            Color = "Синій",
            Price = 1599,
            StockQuantity = 8,
            Description = "Джинси приталеного крою з еластичної тканини."
        });
        Products.Add(new Product
        {
            Id = _nextProductId++,
            Name = "Худі Urban",
            Category = "Верхній одяг",
            Size = "XL",
            Color = "Чорний",
            Price = 1899,
            StockQuantity = 10,
            Description = "Тепле худі з м'якою підкладкою."
        });
        Products.Add(new Product
        {
            Id = _nextProductId++,
            Name = "Сорочка Classic",
            Category = "Сорочки",
            Size = "M",
            Color = "Блакитний",
            Price = 1299,
            StockQuantity = 11,
            Description = "Класична сорочка для офісу та подій."
        });
    }
}
