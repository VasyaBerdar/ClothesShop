﻿using System.Windows;
using Магазин_одягу.Pages;
using Магазин_одягу.Services;

namespace Магазин_одягу
{
    public partial class App : Application
    {
        private readonly StoreService _store = new();

        private void ApplicationStartup(object sender, StartupEventArgs e)
        {
            // Prevent app shutdown while temporary startup dialogs are closing.
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            var startupWindow = new StartupWindow(_store);
            var startupResult = startupWindow.ShowDialog();
            if (startupResult != true)
            {
                Shutdown();
                return;
            }

            var mainWindow = new MainWindow(_store, startupWindow.IsAdmin);
            MainWindow = mainWindow;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            mainWindow.Show();
        }
    }
}
