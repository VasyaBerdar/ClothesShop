﻿using System.Windows;
using System.Windows.Controls;
using Магазин_одягу.Pages;
using Магазин_одягу.Services;

namespace Магазин_одягу
{
    public partial class MainWindow : Window
    {
        private readonly StoreService _store;
        private bool _isAdminAuthorized;

        public MainWindow(StoreService store, bool isAdminAuthorized)
        {
            InitializeComponent();
            _store = store;
            _isAdminAuthorized = isAdminAuthorized;

            if (_isAdminAuthorized)
            {
                UserTextBlock.Text = "Режим: Адміністратор";
                AdminButton.Content = "Адмін панель";
                Navigate(new AdminPanelPage(_store));
                return;
            }

            UserTextBlock.Text = _store.CurrentUser is null
                ? "Режим: Клієнт"
                : $"Користувач: {_store.CurrentUser.FullName}";
            Navigate(new CatalogPage(_store, Navigate));
        }

        private void GoCatalogClick(object sender, RoutedEventArgs e)
        {
            Navigate(new CatalogPage(_store, Navigate));
        }

        private void GoCartClick(object sender, RoutedEventArgs e)
        {
            Navigate(new CartPage(_store, _store.CurrentUser));
        }

        private void AdminClick(object sender, RoutedEventArgs e)
        {
            if (!_isAdminAuthorized)
            {
                var loginWindow = new AdminLoginWindow(_store) { Owner = this };
                loginWindow.ShowDialog();
                if (!loginWindow.IsAuthorized)
                {
                    return;
                }

                _isAdminAuthorized = true;
                AdminButton.Content = "Адмін панель";
            }

            Navigate(new AdminPanelPage(_store));
        }

        private void Navigate(Page page)
        {
            MainFrame.Navigate(page);
        }
    }
}