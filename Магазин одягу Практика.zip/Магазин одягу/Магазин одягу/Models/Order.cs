namespace Магазин_одягу.Models;

public enum OrderStatus
{
    New,
    Processing,
    Completed,
    Cancelled
}

public class Order
{
    public int Id { get; set; }
    public List<OrderItem> Items { get; set; } = [];
    public decimal TotalAmount { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.New;
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
