namespace Магазин_одягу.Models;

public class CartItem
{
    public Product Product { get; set; } = new();
    public int Quantity { get; set; }
    public decimal LineTotal => Product.Price * Quantity;
}
