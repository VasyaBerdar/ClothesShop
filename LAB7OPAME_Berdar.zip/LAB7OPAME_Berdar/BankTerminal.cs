﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB7OPAME_Berdar
{
    public class BankTerminal
    {
        public event Action<int> OnMoneyWithdraw;

        public void Withdraw(int amount)
        {
            Console.WriteLine($"Зняття грошей: {amount}");
            OnMoneyWithdraw?.Invoke(amount);
        }
    }
}
