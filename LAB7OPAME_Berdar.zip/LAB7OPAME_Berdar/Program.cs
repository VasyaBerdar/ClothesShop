﻿namespace LAB7OPAME_Berdar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Task1();
            //BankTerminal terminal = new BankTerminal();

            // terminal.OnMoneyWithdraw += amount =>
            //       Console.WriteLine($"{amount}");

            // terminal.Withdraw(100);

            Task3();
        }
        private static void Task1()
        {
            List<Action> actions = new List<Action>();

            for (int i = 1; i <= 5; i++)
            {
                int current = i; 
                actions.Add(() =>
                {
                    Console.WriteLine(current);
                });
            }

 
            foreach (var action in actions)
            {
                action();
            }
        }

        private static void Task3()
        {
            Func<double, double>[] discounts = new Func<double, double>[]
        {
            price => price * 0.95,   
            price => price * 0.90,  
            price => price - 100     
        };

            double price = 1000;
            int count = 1;
            foreach (var discount in discounts)
            {
                Console.WriteLine($"Ціна після знижки номером номер {count}");
                price = discount(price);
                Console.WriteLine(price);
                count++;
            }
        }
    }
}
