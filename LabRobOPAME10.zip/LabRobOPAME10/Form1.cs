namespace LabRobOPAME10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.MouseClick += Form1_MouseClick;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.X < this.ClientSize.Width / 2)
            {
                Button button = new Button();

                button.Parent = this;
                button.Location = new Point(e.X, e.Y);
                button.Size = new Size(120, 35);
                button.Text = "Кнопка";

                this.Controls.Add(button);
            }
            else
            {
                TextBox textBox = new TextBox();

                textBox.Parent = this;
                textBox.Location = new Point(e.X, e.Y);
                textBox.Size = new Size(120, 25);
                textBox.Text = "Поле вводу";

                this.Controls.Add(textBox);
            }
        }
    }
}
