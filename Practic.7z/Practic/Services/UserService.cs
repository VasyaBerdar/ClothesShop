﻿using Practic.Model;
using Practic.Utilities;
using System;
using System.Collections.Generic;
using System.IO;

namespace Practic.Services
{
    public static class UserService
    {
        private static string path = "users.txt";

        public static List<User> LoadUsers()
        {
            var users = new List<User>();
            if (!File.Exists(path)) File.Create(path).Close();

            var lines = File.ReadAllLines(path);
            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split(';');
                if (parts.Length != 5) continue;

                users.Add(new User
                {
                    Id = int.Parse(parts[0]),
                    Login = parts[1],
                    Password = parts[2],
                    Role = (Role)Enum.Parse(typeof(Role), parts[3]),
                    Balance = double.Parse(parts[4])
                });
            }

            return users;
        }

        public static void SaveUsers(List<User> users)
        {
            var lines = new List<string>();
            foreach (var u in users)
                lines.Add($"{u.Id};{u.Login};{u.Password};{u.Role};{u.Balance}");

            File.WriteAllLines(path, lines);
        }

        public static void CreateAdmin()
        {
            var users = LoadUsers();
            foreach (var u in users)
                if (u.Role == Role.Admin) return;

            int id = users.Count > 0 ? users[^1].Id + 1 : 1;
            users.Add(new User
            {
                Id = id,
                Login = "admin",
                Password = "admin1234",
                Balance = 0,
                Role = Role.Admin
            });

            SaveUsers(users);
        }

        public static bool Register(string login, string password)
        {
            if (string.IsNullOrWhiteSpace(login) || login.Length < 3) return false;
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8) return false;

            var users = LoadUsers();
            foreach (var u in users)
                if (u.Login == login) return false;

            int id = users.Count > 0 ? users[^1].Id + 1 : 1;
            users.Add(new User
            {
                Id = id,
                Login = login,
                Password = password,
                Role = Role.User
            });

            SaveUsers(users);
            return true;
        }

        public static User Login(string login, string password)
        {
            var users = LoadUsers();
            foreach (var u in users)
                if (u.Login == login && u.Password == password)
                    return u;

            return null;
        }

        public static void RemoveUser(string login)
        {
            var users = LoadUsers();
            users.RemoveAll(u => u.Login == login && u.Role != Role.Admin);
            SaveUsers(users);
        }
    }
}
