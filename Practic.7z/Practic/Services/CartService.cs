﻿using Practic.Model;

namespace Practic.Services
{
    public class CartService
    {
        private Cart cart = new Cart();

        public void Add(Clothing item)
        {
            cart.Add(item);
        }

        public double Total()
        {
            return cart.Total();
        }

        public void Clear()
        {
            cart.Clear();
        }

        public Cart GetCart()
        {
            return cart;
        }
    }
}
