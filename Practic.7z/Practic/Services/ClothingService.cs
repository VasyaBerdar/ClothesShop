﻿using Practic.Model;
using System;
using System.Collections.Generic;
using System.IO;

namespace Practic.Services
{
    public static class ClothingService
    {
        private static string path = "clothes.txt";

        public static List<Clothing> LoadClothes()
        {
            var clothes = new List<Clothing>();
            if (!File.Exists(path)) File.Create(path).Close();

            var lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;
                string[] parts = line.Split(';');
                if (parts.Length < 6) continue;

                Clothing c = new Clothing();
                c.Id = int.Parse(parts[0]);
                c.Name = parts[1];
                c.Price = double.Parse(parts[2]);
                c.Category = parts[3];
                c.Size = parts[4];
                c.Stock = int.Parse(parts[5]);
                clothes.Add(c);
            }

            return clothes;
        }

        private static void SaveClothes(List<Clothing> clothes)
        {
            string[] lines = new string[clothes.Count];
            for (int i = 0; i < clothes.Count; i++)
            {
                lines[i] = clothes[i].Id + ";" + clothes[i].Name + ";" + clothes[i].Price + ";" +
                           clothes[i].Category + ";" + clothes[i].Size + ";" + clothes[i].Stock;
            }
            File.WriteAllLines(path, lines);
        }

        public static void AddClothing(string name, double price, string category, string size, int stock)
        {
            var clothes = LoadClothes();
            int id = clothes.Count > 0 ? clothes[clothes.Count - 1].Id + 1 : 1;

            clothes.Add(new Clothing { Id = id, Name = name, Price = price, Category = category, Size = size, Stock = stock });
            SaveClothes(clothes);
        }

        public static void RemoveClothing(int id)
        {
            var clothes = LoadClothes();
            for (int i = clothes.Count - 1; i >= 0; i--)
            {
                if (clothes[i].Id == id)
                    clothes.RemoveAt(i);
            }
            SaveClothes(clothes);
        }
        public static void SaveAllClothes(List<Clothing> clothes)
        {
            var lines = new List<string>();
            for (int i = 0; i < clothes.Count; i++)
            {
                var c = clothes[i];
                lines.Add($"{c.Id};{c.Name};{c.Price};{c.Category};{c.Size};{c.Stock}");
            }
            File.WriteAllLines(path, lines);
        }


    }
}
