﻿using Practic.Menus;
using System;
using System.Text;

namespace Practic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            new AuthMenu().StartUp();
        }
    }
}
