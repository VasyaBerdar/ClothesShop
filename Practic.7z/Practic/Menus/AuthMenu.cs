﻿using Practic.Model;
using Practic.Services;
using Practic.Utilities;
using System;

namespace Practic.Menus
{
    public class AuthMenu
    {
        public void StartUp()
        {
            Console.WriteLine("StyleWave — Online Clothing Store");
            Console.WriteLine("Студент: Василь Бердар");
            Console.WriteLine("Група: КН-21");
            Console.WriteLine();

            UserService.CreateAdmin();

            while (true)
            {
                Console.WriteLine("1 - Реєстрація");
                Console.WriteLine("2 - Авторизація");
                Console.WriteLine("0 - Вихід");

                var choice = Console.ReadLine();
                if (choice == "0") return;

                if (choice == "1") Register();
                else if (choice == "2") Login();
            }
        }

        private void Register()
        {
            Console.Write("Логін: ");
            var login = Console.ReadLine();
            Console.Write("Пароль: ");
            var password = Console.ReadLine();

            if (UserService.Register(login, password))
                Console.WriteLine("Реєстрація успішна");
            else
                Console.WriteLine("Помилка реєстрації (такий логін існує або пароль <8 символів)");
        }

        private void Login()
        {
            Console.Write("Логін: ");
            var login = Console.ReadLine();
            Console.Write("Пароль: ");
            var password = Console.ReadLine();

            var user = UserService.Login(login, password);
            if (user == null)
            {
                Console.WriteLine("Невірні дані");
                return;
            }

            if (user.Role == Role.Admin)
                new AdminMenu(user).Show();
            else
                new UserMenu(user).Show();
        }
    }
}
