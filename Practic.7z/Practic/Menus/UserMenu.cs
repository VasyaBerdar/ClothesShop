﻿using Practic.Model;
using Practic.Services;
using System;
using System.Collections.Generic;

namespace Practic.Menus
{
    public class UserMenu
    {
        private User user;
        private Cart cart = new Cart();
        private List<Clothing> clothes;

        public UserMenu(User user)
        {
            this.user = user;
            clothes = ClothingService.LoadClothes();
        }

        public void Show()
        {
            while (true)
            {
                Console.WriteLine("1 - Перегляд одягу");
                Console.WriteLine("2 - Купити одяг");
                Console.WriteLine("3 - Перейти до оплати");
                Console.WriteLine("4 - Поповнити баланс");
                Console.WriteLine("0 - Вихід");

                string choice = Console.ReadLine();

                if (choice == "0") return;
                if (choice == "1") ShowClothes();
                if (choice == "2") BuyClothes();
                if (choice == "3") Pay();
                if (choice == "4") AddBalance();
            }
        }

        private void ShowClothes()
        {
            for (int i = 0; i < clothes.Count; i++)
            {
                var c = clothes[i];
                Console.WriteLine($"{c.Id}. {c.Name} | {c.Price} | {c.Category} | {c.Size} | Stock: {c.Stock}");
            }
        }

        private void BuyClothes()
        {
            Console.Write("ID одягу для покупки: ");
            int id;
            if (!int.TryParse(Console.ReadLine(), out id))
            {
                Console.WriteLine("Помилка ID");
                return;
            }

            Clothing selected = null;
            for (int i = 0; i < clothes.Count; i++)
            {
                if (clothes[i].Id == id)
                {
                    selected = clothes[i];
                    break;
                }
            }

            if (selected == null)
            {
                Console.WriteLine("Одяг не знайдено");
                return;
            }

            if (selected.Stock <= 0)
            {
                Console.WriteLine("На складі немає цього товару");
                return;
            }

            selected.Stock -= 1;
            cart.Add(selected);
            Console.WriteLine("Додано в кошик");

            for (int i = 0; i < clothes.Count; i++)
            {
                if (clothes[i].Id == selected.Id)
                {
                    clothes[i] = selected;
                    break;
                }
            }

            ClothingService.SaveAllClothes(clothes);
        }

        private void Pay()
        {
            double total = cart.Total();
            if (total > user.Balance)
            {
                Console.WriteLine($"У вас недостатньо грошей. Баланс: {user.Balance}, сума покупки: {total}");
                return;
            }

            user.Balance -= total;

            var users = UserService.LoadUsers();
            for (int i = 0; i < users.Count; i++)
            {
                if (users[i].Login == user.Login)
                {
                    users[i].Balance = user.Balance;
                    break;
                }
            }
            UserService.SaveUsers(users);

            Console.WriteLine($"Оплата успішна. Новий баланс: {user.Balance}");
            cart.Clear();
        }

        private void AddBalance()
        {
            Console.Write("Скільки поповнити: ");
            double amount;
            if (double.TryParse(Console.ReadLine(), out amount) && amount > 0)
            {
                user.Balance += amount;

                var users = UserService.LoadUsers();
                for (int i = 0; i < users.Count; i++)
                {
                    if (users[i].Login == user.Login)
                    {
                        users[i].Balance = user.Balance;
                        break;
                    }
                }
                UserService.SaveUsers(users);

                Console.WriteLine($"Баланс поповнено. Новий баланс: {user.Balance}");
            }
            else
            {
                Console.WriteLine("Невірна сума");
            }
        }
    }
}
