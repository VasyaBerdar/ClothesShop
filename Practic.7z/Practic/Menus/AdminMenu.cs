﻿using Practic.Model;
using Practic.Services;
using Practic.Utilities;
using System;
using System.Collections.Generic;

namespace Practic.Menus
{
    public class AdminMenu
    {
        private User admin;

        public AdminMenu(User admin)
        {
            this.admin = admin;
        }

        public void Show()
        {
            while (true)
            {
                Console.WriteLine("\n1 - Перегляд одягу");
                Console.WriteLine("2 - Додати одяг");
                Console.WriteLine("3 - Видалити одяг");
                Console.WriteLine("4 - Видалити користувача");
                Console.WriteLine("5 - Редагувати користувача");
                Console.WriteLine("6 - Редагувати одяг");
                Console.WriteLine("0 - Вихід");

                string choice = Console.ReadLine();

                if (choice == "0") return;
                if (choice == "1") ShowClothes();
                else if (choice == "2") AddClothing();
                else if (choice == "3") RemoveClothing();
                else if (choice == "4") RemoveUser();
                else if (choice == "5") EditUser();
                else if (choice == "6") EditClothing();
                else Console.WriteLine("Невірний пункт меню.");
            }
        }

        private void ShowClothes()
        {
            var clothes = ClothingService.LoadClothes();
            if (clothes.Count == 0)
            {
                Console.WriteLine("Список одягу порожній.");
                return;
            }

            foreach (var c in clothes)
            {
                Console.WriteLine($"{c.Id}. {c.Name} | {c.Price} | {c.Category} | {c.Size} | Stock: {c.Stock}");
            }
        }

        private void AddClothing()
        {
            Console.Write("Назва: ");
            string name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name) || name.Length < 4)
            {
                Console.WriteLine("Назва повинна містити мінімум 4 символи.");
                return;
            }

            Console.Write("Ціна: ");
            if (!double.TryParse(Console.ReadLine(), out double price))
            {
                Console.WriteLine("Некоректна ціна.");
                return;
            }

            Console.Write("Категорія: ");
            string category = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(category) || category.Length < 4)
            {
                Console.WriteLine("Категорія повинна містити мінімум 4 символи.");
                return;
            }

            Console.Write("Розмір: ");
            string size = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(size) || !double.TryParse(size, out double newSize))
            {
                Console.WriteLine("Некоректний розмір");
                return;
            }

            Console.Write("Кількість: ");
            if (!int.TryParse(Console.ReadLine(), out int stock))
            {
                Console.WriteLine("Некоректна кількість.");
                return;
            }

            ClothingService.AddClothing(name, price, category, newSize.ToString(), stock);
            Console.WriteLine("Одяг додано.");
        }

        private void RemoveClothing()
        {
            var clothes = ClothingService.LoadClothes();
            if (clothes.Count == 0)
            {
                Console.WriteLine("Список одягу порожній.");
                return;
            }

            foreach (var c in clothes)
                Console.WriteLine($"{c.Id}. {c.Name}");

            Console.Write("ID одягу: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Некоректний ID.");
                return;
            }

            if (!clothes.Exists(c => c.Id == id))
            {
                Console.WriteLine("Одяг з таким ID не знайдено.");
                return;
            }

            ClothingService.RemoveClothing(id);
            Console.WriteLine("Одяг видалено.");
        }

        private void ShowUsers(List<User> users)
        {
            foreach (var user in users)
            {
                if (user.Role == Role.Admin) continue;
                if (user.Login == admin.Login) continue;

                Console.WriteLine($"{user.Login} | Баланс: {user.Balance}");
            }
        }

        private void RemoveUser()
        {
            var users = UserService.LoadUsers();
            ShowUsers(users);

            Console.Write("Логін користувача: ");
            string login = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(login))
            {
                Console.WriteLine("Логін не може бути порожнім.");
                return;
            }

            if (login == admin.Login)
            {
                Console.WriteLine("Ви не можете видалити себе.");
                return;
            }

            if (!users.Exists(u => u.Login == login))
            {
                Console.WriteLine("Користувача не знайдено.");
                return;
            }

            UserService.RemoveUser(login);
            Console.WriteLine("Користувач видалений.");
        }

        private void EditUser()
        {
            var users = UserService.LoadUsers();
            ShowUsers(users);

            Console.Write("Логін користувача: ");
            string login = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(login))
            {
                Console.WriteLine("Логін не може бути порожнім.");
                return;
            }

            User user = users.Find(u => u.Login == login);
            if (user == null)
            {
                Console.WriteLine("Користувача не знайдено.");
                return;
            }

            if (user.Role == Role.Admin || user.Login == admin.Login)
            {
                Console.WriteLine("Редагування заборонено.");
                return;
            }

            Console.Write("Новий пароль: ");
            string password = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
            {
                Console.WriteLine("Пароль має містити мінімум 8 символів.");
                return;
            }

            Console.Write("Новий баланс: ");
            if (!double.TryParse(Console.ReadLine(), out double balance))
            {
                Console.WriteLine("Некоректний баланс.");
                return;
            }

            user.Password = password;
            user.Balance = balance;

            UserService.SaveUsers(users);
            Console.WriteLine("Користувача оновлено.");
        }

        private void EditClothing()
        {
            var clothes = ClothingService.LoadClothes();
            if (clothes.Count == 0)
            {
                Console.WriteLine("Список одягу порожній.");
                return;
            }

            foreach (var c in clothes)
                Console.WriteLine($"{c.Id}. {c.Name}");

            Console.Write("ID одягу: ");
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Некоректний ID.");
                return;
            }

            Clothing item = clothes.Find(c => c.Id == id);
            if (item == null)
            {
                Console.WriteLine("Одяг не знайдено.");
                return;
            }

            Console.Write("Назва: ");
            string name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name) || name.Length < 4)
            {
                Console.WriteLine("Назва повинна містити мінімум 4 символи.");
                return;
            }

            Console.Write("Ціна: ");
            if (!double.TryParse(Console.ReadLine(), out double price))
            {
                Console.WriteLine("Некоректна ціна.");
                return;
            }

            Console.Write("Категорія: ");
            string category = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(category) || category.Length < 4)
            {
                Console.WriteLine("Категорія повинна містити мінімум 4 символи.");
                return;
            }

            Console.Write("Розмір: ");
            string size = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(size) || !double.TryParse(size,out double newSize))
                
            {
                Console.WriteLine("Некоректний розмір.");
                return;
            }

            Console.Write("Кількість: ");
            if (!int.TryParse(Console.ReadLine(), out int stock))
            {
                Console.WriteLine("Некоректна кількість.");
                return;
            }

            item.Name = name;
            item.Price = price;
            item.Category = category;
            item.Size = newSize.ToString();
            item.Stock = stock;

            ClothingService.SaveAllClothes(clothes);
            Console.WriteLine("Одяг оновлено.");
        }
    }
}
