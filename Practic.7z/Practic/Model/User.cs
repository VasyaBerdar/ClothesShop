﻿using Practic.Utilities;
namespace Practic.Model
{
    public class User
    {
        public int Id { get; set; }
        public string Login { get;  set; }
        public string Password { get;  set; }
        public double Balance { get; set; }
        public Role Role { get;  set; }
    }
}
