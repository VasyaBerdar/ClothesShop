﻿using System.Collections.Generic;

namespace Practic.Model
{
    public class Cart
    {
        private List<Clothing> items = new List<Clothing>();

        public void Add(Clothing item)
        {
            items.Add(item);
        }

        public double Total()
        {
            double sum = 0;
            for (int i = 0; i < items.Count; i++)
            {
                sum += items[i].Price;
            }
            return sum;
        }

        public void Clear()
        {
            items.Clear();
        }

        public List<Clothing> Items()
        {
            return items;
        }
    }
}
