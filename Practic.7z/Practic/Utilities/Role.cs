﻿
namespace Practic.Utilities
{
   public enum Role {User,Admin }
}
